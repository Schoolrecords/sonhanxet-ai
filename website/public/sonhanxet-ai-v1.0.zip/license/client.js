/**
 * License Client v2 cho "Sổ nhận xét - AI"
 * =========================================
 *
 * Mô hình self-serve (đổi 2026-05-15):
 *   1. dangKy(sdt, hoTen) → server cấp mã 6 ký tự (vd k7m3pr)
 *   2. GV chuyển khoản, thầy tick "đã thanh toán" trong Sheet
 *   3. dangNhap(sdt, ma) → bind thiết bị → mở khóa
 *   4. Re-check server mỗi 7 ngày
 *
 * Bỏ email. Bỏ kiểu mã GV000001.
 */

(function () {
    'use strict';

    // URL GAS Web App của thầy Chung (deploy 2026-05-15). Đổi khi deploy version mới.
    const LICENSE_API_URL = 'https://script.google.com/macros/s/AKfycbwkUaBdK2PJN61NipPDDklD1Lhs4xrpdrcmFjJJQc0W80kpw2KASKdmMTn-pjAHqZfw/exec';

    const STORAGE_KEY = 'license_v2';
    const PENDING_KEY = 'license_pending_v2';   // đăng ký rồi, chờ thanh toán
    const FREE_KEY = 'free_subject_v2';
    const FP_KEY = 'device_fp_v1';              // giữ key cũ để fingerprint stable
    const LAST_SDT_KEY = 'last_sdt_v1';         // nhớ SĐT cuối, GV quay lại đăng nhập đỡ phải gõ

    const RECHECK_AFTER_DAYS = 7;
    const OFFLINE_GRACE_DAYS = 30;
    const MA_LEN = 4;  // đồng bộ với MA_BI_MAT_LEN trên server

    // ---------- Device fingerprint ----------

    async function getDeviceFingerprint() {
        const cached = await storageGet(FP_KEY);
        if (cached) return cached;

        // v0.1.21: CHỈ dùng phần cứng (không có UUID phần mềm). Đảm bảo fingerprint
        // ổn định mãi mãi trên cùng máy, kể cả khi GV clear chrome.storage hoặc cài
        // lại extension. Trước đây UUID bị xóa → fingerprint khác → server tưởng máy mới.
        const parts = [
            navigator.hardwareConcurrency || 0,
            navigator.deviceMemory || 0,
            screen.width + 'x' + screen.height + 'x' + screen.colorDepth,
            screen.availWidth + 'x' + screen.availHeight,
            navigator.platform || '',
            navigator.language || '',
            (navigator.languages || []).join(','),
            Intl.DateTimeFormat().resolvedOptions().timeZone || '',
            canvasFingerprint()
        ].join('|');
        const fp = await sha256Hex(parts);
        const short = fp.slice(0, 32);
        await storageSet(FP_KEY, short);
        return short;
    }

    function canvasFingerprint() {
        try {
            const c = document.createElement('canvas');
            c.width = 200; c.height = 50;
            const ctx = c.getContext('2d');
            ctx.textBaseline = 'top';
            ctx.font = '14px "Arial"';
            ctx.fillStyle = '#f60';
            ctx.fillRect(0, 0, 100, 30);
            ctx.fillStyle = '#069';
            ctx.fillText('Sổ NX AI · canvas FP', 2, 15);
            ctx.strokeStyle = 'rgba(102,204,0,0.7)';
            ctx.beginPath();
            ctx.arc(50, 25, 10, 0, Math.PI * 2, true);
            ctx.stroke();
            return c.toDataURL().slice(-80);
        } catch (e) { return 'no-canvas'; }
    }

    async function sha256Hex(s) {
        const data = new TextEncoder().encode(s);
        const buf = await crypto.subtle.digest('SHA-256', data);
        return Array.from(new Uint8Array(buf))
            .map(b => b.toString(16).padStart(2, '0')).join('');
    }

    function randomHex(n) {
        const a = new Uint8Array(n);
        crypto.getRandomValues(a);
        return Array.from(a).map(b => b.toString(16).padStart(2, '0')).join('');
    }

    // ---------- Chuẩn hóa ----------

    function normalizeSdt(s) {
        if (!s) return null;
        let t = String(s).replace(/\D/g, '');
        if (t.startsWith('84')) t = '0' + t.slice(2);
        if (t.length !== 10 || !t.startsWith('0')) return null;
        return t;
    }

    function normalizeMa(s) {
        return String(s || '').trim().toLowerCase().replace(/[^a-z0-9]/g, '');
    }

    // ---------- Chrome storage ----------

    function storageGet(key) {
        return new Promise((resolve) => {
            try { chrome.storage.local.get([key], r => resolve(r?.[key])); }
            catch (e) { resolve(undefined); }
        });
    }
    function storageSet(key, value) {
        return new Promise((resolve) => {
            try { chrome.storage.local.set({ [key]: value }, () => resolve()); }
            catch (e) { resolve(); }
        });
    }
    function storageRemove(key) {
        return new Promise((resolve) => {
            try { chrome.storage.local.remove([key], () => resolve()); }
            catch (e) { resolve(); }
        });
    }

    // ---------- Server calls ----------

    async function callServer(action, payload) {
        console.log('[License] callServer action=' + action, payload);
        if (!LICENSE_API_URL || LICENSE_API_URL.indexOf('PASTE_') === 0) {
            console.error('[License] LICENSE_API_URL chưa cấu hình!');
            return { ok: false, error: 'server_chua_cau_hinh' };
        }
        const body = JSON.stringify(Object.assign({ action }, payload));
        console.log('[License] POST →', LICENSE_API_URL);
        console.log('[License] body:', body);
        try {
            const res = await fetch(LICENSE_API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: body,
                redirect: 'follow'
            });
            console.log('[License] response status:', res.status, res.statusText);
            const text = await res.text();
            console.log('[License] response body:', text);
            if (!res.ok) return { ok: false, error: 'http_' + res.status, raw: text };
            try {
                return JSON.parse(text);
            } catch (parseErr) {
                console.error('[License] không parse được JSON:', parseErr, 'body:', text);
                return { ok: false, error: 'parse_error', raw: text };
            }
        } catch (e) {
            console.error('[License] fetch THROW:', e);
            return { ok: false, error: 'network', detail: String(e) };
        }
    }

    // ---------- Public API ----------

    /**
     * Đọc trạng thái tổng hợp để UI render.
     * status:
     *   'active'         — đã đăng nhập, còn hạn
     *   'pending'        — đã đăng ký, chờ thanh toán / chờ đăng nhập (có pending trong storage)
     *   'expired'        — license cũ hết hạn
     *   'needs_recheck'  — offline quá 30 ngày
     *   'free'           — chưa đăng ký gì
     */
    async function getState() {
        const lic = await storageGet(STORAGE_KEY);
        // v0.1.21: coi là active nếu có sdt (đã đăng nhập). Fallback validUntil
        // = activatedAt + 365 ngày nếu server không trả về hạn (admin chỉ tick tay).
        if (lic && lic.sdt) {
            let validUntilMs;
            if (lic.validUntil) {
                validUntilMs = new Date(lic.validUntil).getTime();
            } else if (lic.activatedAt) {
                validUntilMs = new Date(lic.activatedAt).getTime() + 365 * 86400000;
                lic.validUntil = new Date(validUntilMs).toISOString().slice(0, 10);
            } else {
                validUntilMs = Date.now() + 365 * 86400000;
                lic.validUntil = new Date(validUntilMs).toISOString().slice(0, 10);
            }
            const lastCheckMs = new Date(lic.lastCheckedAt || 0).getTime();
            const daysSinceCheck = (Date.now() - lastCheckMs) / 86400000;

            if (validUntilMs < Date.now()) return { status: 'expired', ...lic };
            if (daysSinceCheck > OFFLINE_GRACE_DAYS) return { status: 'needs_recheck', ...lic };
            return { status: 'active', ...lic, daysSinceCheck };
        }

        const pending = await storageGet(PENDING_KEY);
        if (pending && pending.sdt && pending.ma) {
            return { status: 'pending', ...pending };
        }

        const freeSubject = await storageGet(FREE_KEY);
        return { status: 'free', freeSubject: freeSubject || null };
    }

    /**
     * Đăng ký mới — server sinh mã 6 ký tự.
     * Lưu pending trong storage để UI render "đang chờ thanh toán".
     */
    async function dangKy(sdt, hoTen) {
        sdt = normalizeSdt(sdt);
        hoTen = String(hoTen || '').trim().replace(/\s+/g, ' ');
        if (!sdt) return { ok: false, error: 'sdt_sai' };
        if (hoTen.length < 3) return { ok: false, error: 'ho_ten_sai' };

        const res = await callServer('dangKy', { sdt, hoTen });
        if (res.ok) {
            await storageSet(PENDING_KEY, {
                sdt: res.sdt,
                hoTen: res.hoTen,
                ma: res.ma,
                soTien: res.soTien || 50000,
                createdAt: new Date().toISOString()
            });
            await storageSet(LAST_SDT_KEY, res.sdt);  // nhớ để form login lần sau auto-fill
        }
        return res;
    }

    /**
     * Đăng nhập — bind thiết bị. Yêu cầu thầy đã tick "đã thanh toán" trong Sheet.
     */
    async function dangNhap(sdt, ma) {
        sdt = normalizeSdt(sdt);
        ma = normalizeMa(ma);
        if (!sdt) return { ok: false, error: 'sdt_sai' };
        if (ma.length !== MA_LEN) return { ok: false, error: 'ma_sai_dinh_dang' };

        const deviceFp = await getDeviceFingerprint();
        const deviceInfo = (navigator.userAgent || '').slice(0, 120);

        const res = await callServer('dangNhap', { sdt, ma, deviceFp, deviceInfo });
        if (res.ok) {
            await storageSet(STORAGE_KEY, {
                sdt: res.sdt,
                gv_ho_ten: res.gv_ho_ten || '',
                validUntil: res.validUntil,
                activatedAt: res.activatedAt,
                lastCheckedAt: new Date().toISOString()
            });
            await storageSet(LAST_SDT_KEY, res.sdt);  // nhớ SĐT cho lần đăng nhập sau
            // Xong giai đoạn pending → xóa
            await storageRemove(PENDING_KEY);
            await storageRemove(FREE_KEY);
        }
        return res;
    }

    async function recheckIfDue() {
        const lic = await storageGet(STORAGE_KEY);
        if (!lic) return { skipped: 'no_license' };

        const lastCheckMs = new Date(lic.lastCheckedAt || 0).getTime();
        const daysSinceCheck = (Date.now() - lastCheckMs) / 86400000;
        if (daysSinceCheck < RECHECK_AFTER_DAYS) return { skipped: 'not_due', daysSinceCheck };

        const deviceFp = await getDeviceFingerprint();
        const res = await callServer('checkLicense', { sdt: lic.sdt, deviceFp });

        if (res.ok) {
            await storageSet(STORAGE_KEY, Object.assign({}, lic, {
                validUntil: res.validUntil,
                lastCheckedAt: new Date().toISOString()
            }));
            return { ok: true };
        }
        if (res.error === 'network') return { skipped: 'offline' };
        await storageRemove(STORAGE_KEY);
        return { ok: false, error: res.error };
    }

    async function clearLocal() {
        // GIỮ LẠI LAST_SDT_KEY để GV quay lại đăng nhập đỡ phải gõ SĐT
        await storageRemove(STORAGE_KEY);
        await storageRemove(PENDING_KEY);
        await storageRemove(FREE_KEY);
    }

    async function clearPending() {
        await storageRemove(PENDING_KEY);
    }

    async function getLastSdt() {
        return (await storageGet(LAST_SDT_KEY)) || '';
    }

    async function canUseFeature(feature, subjectKey) {
        const state = await getState();
        if (state.status === 'active') return { allowed: true };
        if (state.status === 'expired' || state.status === 'needs_recheck') {
            return { allowed: false, reason: state.status };
        }
        // pending hoặc free → cùng quota miễn phí
        if (feature === 'nlpc') return { allowed: false, reason: 'free_no_nlpc' };
        if (feature === 'subject') {
            if (!subjectKey) return { allowed: false, reason: 'missing_subject' };
            if (!state.freeSubject) return { allowed: true, willLockTo: subjectKey };
            if (state.freeSubject === subjectKey) return { allowed: true };
            return { allowed: false, reason: 'free_other_subject', freeSubject: state.freeSubject };
        }
        return { allowed: false, reason: 'unknown_feature' };
    }

    async function commitFreeSubject(subjectKey) {
        const state = await getState();
        if (state.status === 'active') return;
        if (state.freeSubject) return;
        if (!subjectKey) return;
        await storageSet(FREE_KEY, subjectKey);
    }

    window.LicenseClient = {
        getState,
        dangKy,
        dangNhap,
        recheckIfDue,
        clearLocal,
        clearPending,
        canUseFeature,
        commitFreeSubject,
        getDeviceFingerprint,
        getLastSdt,
        FEATURES: { SUBJECT: 'subject', NLPC: 'nlpc' }
    };
})();
